﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Login
{
    public partial class frmChatApp : Form
    {
        frmLogin user;

        public frmChatApp(frmLogin login)
        {
            InitializeComponent();
            user = login as frmLogin; //makes user equal to the active form frmLogin
        }

        //My connection string to connect to the database, the (.) is basically (localhost)
        public string conStr = "Server=.\\SQLEXPRESS; DataBase=MyChatApp; Integrated Security=SSPI;";

        private void btnLogout_Click(object sender, EventArgs e)
        { //this button performs a logout sequence
            DialogResult result = MessageBox.Show("Are you sure?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            { //if the user says yes to logging out, the following happens
                SetUserOffline(); //calls method SetUserOffline
                user.Show(); //displays frmLogin
                user.Reset(); //calls the function reset for frmLogin so it is back to blank
                this.Hide(); //hides this current open form
            }
        }

        public void SetUserOffline()
        {
            SqlConnection conn = new SqlConnection();
            try
            { //this is a stored procedure, that deletes the user from the Online table so that they are
              //no longer seen as online
                conn = new SqlConnection(conStr);
                //string to connect to the database
                conn.Open(); //opens the database connection

                SqlCommand off = new SqlCommand("SetOffline", conn); //a command used to set online to false
                off.CommandType = CommandType.StoredProcedure; //declares the command type as a stored procedure
                off.Parameters.AddWithValue("@User", user.SendEmail()); //adds parameters to the command from this program
                off.ExecuteNonQuery(); //this executes a non query statement, ex: delete, insert
            }
            catch (Exception)
            {
                user.UhOh(); //this is a method I use when an unexpected error occurs
            }
            finally
            {
                conn.Close(); //closes the database connection
            }
        }

        public int i = 0;
        //a global integer declared to use within a method (will change with the program opposed to the method alone)

        private void btnSend_Click(object sender, EventArgs e)
        { //this button is used to send messages to other users on the chat app
            if (txtMessage.Text == "")
            { //if the textbox is left blank the following happens
                MessageBox.Show("You cannot leave the textbox blank."); //Error Message
                txtMessage.Focus(); //sets focus on the textbox
            }
            else
            { //if it was not left blank the following happens
                GetMessageInfo(); //calls the method GetMessageInfo
                txtMessage.Clear(); //clears the text in the textbox
                txtMessage.Focus(); //sets focus on the textbox
            }
        }

        public void GetMessageInfo()
        {
            string systemID = user.systemID(); //takes the systemID from the user currently logged in to use with the method
            SqlConnection conn = new SqlConnection();
            try
            {
                conn = new SqlConnection(conStr);
                conn.Open(); //opens the connection to the database

                SqlCommand sir = new SqlCommand("IdentifyUser", conn); //a command used to identify the user
                sir.CommandType = CommandType.StoredProcedure; //declares the command type as stored procedure
                sir.Parameters.AddWithValue("@User", user.SendEmail()); //adds parameters to the command
                int Id = (int)sir.ExecuteScalar(); //a single execution to get the Id of the user logged in

                SqlCommand cmd = new SqlCommand("GetMessages", conn); //a command used to insert messages to the database
                cmd.CommandType = CommandType.StoredProcedure; //declares the command type as stored procedure
                cmd.Parameters.AddWithValue("@Message", txtMessage.Text); //adds parameters to the command
                cmd.Parameters.AddWithValue("@User", Id); //adds parameters to the command
                cmd.Parameters.AddWithValue("@SystemId", systemID); //adds parameters to the command
                cmd.ExecuteNonQuery(); //this executes a non query statement, ex: delete, insert
            }
            catch (Exception)
            {
                user.UhOh(); //this is a method I use when an unexpected error occurs
            }
            finally
            {
                conn.Close(); //closes the connection to the database
            }
        }

        public int n = 0; //numbers to be changed within a method, doesnt reset each time the method is called

        private void Refresh()
        {
            if (n != 1)
            { //if n doesnt equal 1 the following happens (this is basically how I want the form to load)
                txtMessages.SelectionStart = txtMessages.Text.Length; 
                txtMessages.ScrollToCaret();
                txtMessages.Refresh(); //this and the two lines above make it so that the textbox begins at the bottom
                n++; //adds 1 to n (this makes it so that everything within the if statement are only performed once)
            }

            SqlConnection conn = new SqlConnection();
            try
            {
                conn = new SqlConnection(conStr);
                //connection string to the database
                conn.Open(); //opens the connection to the database

                SqlCommand lat = new SqlCommand("LatestMessage", conn); //a command to display the latest message sent
                lat.CommandType = CommandType.StoredProcedure; //declares the command type as a stored procedure
                i++; //adds 1 to i to make it equal to the id of the "newest" message sent in the database
                lat.Parameters.AddWithValue("@Message", i); //adds the parameter i to the stored procedure
                SqlDataReader rdr = lat.ExecuteReader(); //creates a datareader to read the data from the table
                if (rdr.Read() == false)
                { //if there hasnt been a new message sent the following happens
                    i--; //this is reset if no new message has been sent so that it can get the next one
                }
                else
                { //if there is a new message the following happens
                    txtMessages.AppendText(Environment.NewLine);
                    //this esentially puts a space between the new message and the message before it
                    txtMessages.AppendText(rdr.GetValue(0) + "   " + rdr.GetValue(2) + Environment.NewLine);
                    //this displays the username and date the message was sent then has it go to the next line
                    txtMessages.AppendText(rdr.GetValue(1) + Environment.NewLine); //this displays the message
                }
                rdr.Close(); //closes the datareader once it is finished

                SqlCommand chk = new SqlCommand("CheckStatus", conn); //a command to check who is currently online
                chk.CommandType = CommandType.StoredProcedure; //declares as stored procedure
                SqlDataReader dr = chk.ExecuteReader(); //a datareader to read the data given from the command
                txtOnline.Text = "Users Online:";
                while (dr.Read())
                { //while the datareader reads the following is done
                    if ((string)dr.GetValue(0) == user.SendEmail())
                        txtOnline.AppendText(Environment.NewLine + "YOU - " + dr.GetValue(0) + " is Online");
                    else
                        txtOnline.AppendText(Environment.NewLine + dr.GetValue(0) + " is Online ");
                }
                dr.Close(); //closes the datareader once it is finished
            } 
            catch (Exception)
            {
                user.UhOh(); //this is a method I use when an unexpected error occurs
            }
            finally
            {
                conn.Close(); //closes the connection to the database
            }
        }

        void timerTick(object sender, EventArgs e)
        {
            Refresh(); //calls the refresh function for each timer interval
        }

        public void OnlineDisplay()
        {

        }
        
        private void frmChatApp_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer(); //declares a timer
            t.Interval = 500; //sets the interval for the timer to 0.5 seconds
            t.Tick += new EventHandler(timerTick); //calls timerTick to handle what happens each interval
            t.Start(); //starts the timer

            SqlConnection conn = new SqlConnection();
            try
            {
                conn = new SqlConnection(conStr);
                //the connection string for the database
                conn.Open(); //opens the connection to the database

                SqlCommand on = new SqlCommand("SetOnline", conn); //a command used to set Online to true
                on.CommandType = CommandType.StoredProcedure; //declares as a stored procedure
                on.Parameters.AddWithValue("@User", user.SendEmail()); //adds parameters to the command
                on.ExecuteNonQuery(); //executes a non query statement

                SqlCommand dis = new SqlCommand("DisplayMessages", conn); //a command used to display all previous messages
                dis.CommandType = CommandType.StoredProcedure; //declares as a stored procedure
                SqlDataReader rdr = dis.ExecuteReader(); //creates a datareader to read the data from the table
                while (rdr.Read())
                { //reads each row in the database and displays in this format
                    txtMessages.AppendText(rdr.GetValue(0) + "   " + rdr.GetValue(2) + Environment.NewLine);
                    //displays the username and date the message was sent
                    txtMessages.AppendText(rdr.GetValue(1) + Environment.NewLine);
                    //displays the message that was sent
                    txtMessages.AppendText(Environment.NewLine);
                    //creates a space between this message and the next one
                    i++; //increments i by 1 for each message so that the latest message will be the latest
                }
                rdr.Close(); //closes the data reader
                txtMessages.AppendText("!--- Older Messages Above ---!" + Environment.NewLine);
                //this is basically the start of the new session, anything above is from a previous session
            }
            catch (Exception)
            {
                user.UhOh();//this is a method I use when an unexpected error occurs
            }
            finally
            {
                conn.Close(); //closes the connection to the database
            }
        }
    }
}
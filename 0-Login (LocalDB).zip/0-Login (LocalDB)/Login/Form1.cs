﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;
using System.IO;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;

namespace Login
{

    public partial class frmLogin : Form
    {

        public frmLogin()
        {
            InitializeComponent();
        }

        //My connection string to connect to the database, the (.) is basically (localhost)
        public string conStr = "Server=.\\SQLEXPRESS; DataBase=MyChatApp; Integrated Security=SSPI;";

        //This is a method to create the database if it doesn't already exist
        public void CreateIfNotExists()
        {
            SqlConnection conn = new SqlConnection();
            try
            {
                conn = new SqlConnection(conStr);
                conn.Open();
            }
            catch(Exception)
            { //this connects to the master database that should be present if SQL Server is installed
                //this must be connected to so that a new database can be created
                conn = new SqlConnection("Server=.\\SQLEXPRESS; DataBase=Master; Integrated Security=SSPI;");
                conn.Open(); //opens the connection
                string create = File.ReadAllText("script.sql"); //the file containing the code to create the database
                ServerConnection svrConnection = new ServerConnection(conn);
                Server db = new Server(svrConnection);
                db.ConnectionContext.ExecuteNonQuery(create);
                //I used this to bypass the "GO" in the sql script (regular SQL connection doesn't like it)
            }
            finally
            {
                conn.Close(); //closes the connection
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text == "" || txtPassword.Text == "")
            { //checks if the email or password textboxes were left blank
                MessageBox.Show("You cannot leave email or password blank.", "Invalid Input", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    SelectAll(); //calls method selectAll
            }
            else
            {
                bool isGood = IsValidEmail(); //calls method isValidEmail to get a true or false value
                if (isGood == false)
                { //if the email isn't correct this happens
                    MessageBox.Show("Please enter a valid email address.", "Invalid Input", 
                        MessageBoxButtons.OK, MessageBoxIcon.Error); //displays error message to user
                        SelectAll(); //calls method selectAll
                }
                else
                {
                    EmailValidation(); //calls method EmailValidation
                }
            }
        }

        public void EmailValidation()
        { //creates a new sqlconnection
            SqlConnection conn = new SqlConnection();
            try
            { //connects to connection string
                conn = new SqlConnection(conStr);
                conn.Open(); //opens connection

                //this sql command checks the database to see if the email exists
                SqlCommand cmd = new SqlCommand("CheckEmail", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                { //if it does, it does the following
                    string pass = "";
                    while (dr.Read())
                    { //checks to see if the password is correct
                        pass = (string)dr.GetValue(2);
                    }
                    if (pass == txtPassword.Text)
                    { //if it is the following happens
                        this.Hide(); //hides this form
                        frmChatApp ChatApp = new frmChatApp(this);
                        ChatApp.Show(); //opens chat app form
                    }
                    else
                    { //if password is not correct the following happens
                        DialogResult result = MessageBox.Show("The password you entered was incorrect.",
                            "Invalid Input", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                        if (result == DialogResult.Cancel)
                            Reset(); //calls method reset
                        else
                        {
                            txtPassword.SelectAll();
                            txtPassword.Focus(); //selects text in textbox and sets focus on it
                        }
                    }
                }
                else
                { //if email isn't valid this happens
                    Registration(); //calls method registration
                }
                dr.Close();
            }
            catch (Exception)
            {
                UhOh(); //my function to display if there is an error I didn't account for
            }
            finally
            { //closes connection
                conn.Close();
            }
        }

        //this method handles user registration to myChatApp
        public void Registration()
        { 
            DialogResult result = MessageBox.Show("The email you entered does not exist. Do you want to register as a new user?",
                        "Invalid Input", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            { //If you say yes to registering this happens
                SqlConnection con = new SqlConnection();
                try
                {
                    con = new SqlConnection(conStr);
                    con.Open(); //connects to string and opens connection

                    //this sql command will add a new user to the user table
                    SqlCommand reg = new SqlCommand("RegisterUsers", con);
                    reg.CommandType = CommandType.StoredProcedure;
                    reg.Parameters.AddWithValue("@User", txtEmail.Text);
                    reg.Parameters.AddWithValue("@Password", txtPassword.Text);
                    reg.ExecuteNonQuery();
                }
                catch (Exception)
                {
                    UhOh(); //my function to display if there is an error I didn't account for
                }
                finally
                {
                    con.Close(); //closes connection
                }
                MessageBox.Show("Registration Success", "Welcome", MessageBoxButtons.OK,
                    MessageBoxIcon.Information); //a welcome message to display that it was successful
                Email(); //calls method email
                this.Hide(); //hides this form
                frmChatApp ChatApp = new frmChatApp(this);
                ChatApp.Show(); //opens chatapp form
            }
            else
                SelectAll(); //calls method selectAll
        }

        //this is a method to get the systemID of the user
        public string systemID()
        {
            string system = Environment.MachineName;
            return system;
        }

        public bool IsValidEmail()
        {
            try
            { //this will check the format of what is entered (ensures it is formatted like an email)
                var addr = new System.Net.Mail.MailAddress(txtEmail.Text);
                //you could still enter a fake email but if it is formatted correctly you can pass
                return true;
            }
            catch
            {
                return false;
            }
        }

        //this method sends an email to the user who registers
        public void Email()
        { 
            try
            {
                SmtpClient client = new SmtpClient("smtp.outlook.com"); //sets the client to use
                MailMessage message = new MailMessage(); //declares new message
                message.From = new MailAddress("mattchatapp@outlook.com"); //sets from
                message.To.Add(txtEmail.Text); //sets to
                message.Subject = "This is an automated welcome message, please do not reply."; //sets subject
                message.Body = "Welcome to my Chat App feel free to send messages and talk to any others."; //sets body
                client.Port = 25; //makes the port STMP
                client.Credentials = new System.Net.NetworkCredential("mattchatapp@outlook.com", "MyApplication");
                //the login to the email it will be sent from
                client.EnableSsl = true;
                client.Send(message); //sends the message to the new user
            }
            catch (Exception)
            {
                UhOh(); //my function to display if there is an error I didn't account for
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Exit Application", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            { //closes the form if somebody choses to exit
                this.Close();
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        { //when the form loads this happens
            Reset(); //resets the form incase anything was leftover from last time (ya never know)
            CreateIfNotExists(); //checks if database exists
        }


        //my function to display if there is an error I didn't account for
        public void UhOh()
        {
            DialogResult result = MessageBox.Show("An unexpected error has occured", "Error",
                        MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            if (result == DialogResult.Abort)
                this.Close(); //if you click abort it exist the application
            else if (result == DialogResult.Retry)
                SelectAll(); //if retry it calls selectAll method
        }

        public string SendEmail()
        { //gets email to send to chatApp form
            return txtEmail.Text;
        }

        public void SelectAll()
        { //selects txtemail sets focus and clears txtpassword
            txtEmail.SelectAll();
            txtEmail.Focus();
            txtPassword.Clear();
        }

        public void Reset()
        { //clears both email and password and sets focus on email
            txtEmail.Focus();
            txtEmail.Clear();
            txtPassword.Clear();
        }
    }
}